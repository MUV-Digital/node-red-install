export enum PointType {
  TEMPERATURE,
  PERFORMANCE,
  FLAG,
}
