import { Gobject } from './Gobject';

export type State = Gobject<Property, Relation>;

interface Property {}

interface Relation {}
