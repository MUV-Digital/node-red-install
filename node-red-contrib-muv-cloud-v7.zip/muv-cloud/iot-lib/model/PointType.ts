export enum PointType {
  TEMPERATURE,
  FLAG,
}
