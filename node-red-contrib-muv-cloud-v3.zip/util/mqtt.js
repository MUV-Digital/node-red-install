export function matchTopic(ts, t) {
    if (ts == "#") {
        return true;
    }
    var re = new RegExp("^" + ts.replace(/([\[\]\?\(\)\\\\$\^\*\.|])/g, "\\$1").replace(/\+/g, "[^/]+").replace(/\/#$/, "(\/.*)?") + "$");
    return re.test(t);
}